
<script src="<?php echo e(asset('assets/vendor/bootstrap/bootstrap.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/fontawesome/all.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-confirm/jquery-confirm.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/date-time-picker/DateTimePicker.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/iro-color-picker/iro.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/fullcalendar/main.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/apex-chart/apexcharts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/file-pond/filepond.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/sb-admin-2.min.js')); ?>"></script><?php /**PATH D:\LaravelWorkspace\your_tasks\resources\views/layouts/vendor/vendor_js.blade.php ENDPATH**/ ?>