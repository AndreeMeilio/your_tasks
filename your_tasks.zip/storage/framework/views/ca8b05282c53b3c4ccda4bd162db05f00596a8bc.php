
<?php $__env->startSection('content'); ?>

<div class="form-check">
    <input class="form-check-input tanggalTugas" type="radio" name="flexRadioDefault" id="flexRadioDefault1" value="tanggaldiberiTugas" checked>
    <label class="form-check-label" for="flexRadioDefault1">
        Lihat berdasarkan tanggal diberi tugas
    </label>
</div>
<div class="form-check">
    <input class="form-check-input tanggalTugas" type="radio" name="flexRadioDefault" id="flexRadioDefault2" value="tanggaldeadlineTugas">
    <label class="form-check-label" for="flexRadioDefault2">
        Lihat berdasarkan tanggal deadline tugas
    </label>
</div>

    <div id="calendarTugas"></div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        var calendarElement = document.getElementById('calendarTugas');
        
        $(document).ready(function(){
            var calendarTugas = new FullCalendar.Calendar(calendarElement, {
                initialView: 'dayGridMonth',
                headerToolbar : {
                    start : 'prev',
                    center : 'title',
                    end : 'next'
                },
                titleFormat : { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                },
                events : [
                    <?php foreach($data_tugas as $value) { ?>
                        {
                            id        : "<?= $value['id']?>",
                            title     : "<?= $value['namaTugas']?>",
                            deskripsi : "<?= $value['deskripsiTugas']?>",
                            start     : "<?= $value['tanggaldiberiTugas']?>",
                            end       : "",
                            backgroundColor : "green"
                        },
                    <?php } ?>
                ]
            });
            calendarTugas.render();


            $(".tanggalTugas").on('change', function(){
                var tanggalTugas = $(this).val();

                if (tanggalTugas == "tanggaldeadlineTugas"){
                    var calendarTugas = new FullCalendar.Calendar(calendarElement, {
                        initialView: 'dayGridMonth',
                        headerToolbar : {
                            start : 'prev',
                            center : 'title',
                            end : 'next'
                        },
                        titleFormat : { 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                        },
                        events : [
                            <?php foreach($data_tugas as $value) { ?>
                                {
                                    id        : "<?= $value['id']?>",
                                    title     : "<?= $value['namaTugas']?>",
                                    deskripsi : "<?= $value['deskripsiTugas']?>",
                                    start     : "<?= $value['tanggaldeadlineTugas']?>",
                                    end       : "",
                                    backgroundColor : "red"
                                },
                            <?php } ?>
                        ]
                    });
                    calendarTugas.render();
                } else {
                    var calendarTugas = new FullCalendar.Calendar(calendarElement, {
                        initialView: 'dayGridMonth',
                        headerToolbar : {
                            start : 'prev',
                            center : 'title',
                            end : 'next'
                        },
                        titleFormat : { 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                        },
                        events : [
                            <?php foreach($data_tugas as $value) { ?>
                                {
                                    id        : "<?= $value['id']?>",
                                    title     : "<?= $value['namaTugas']?>",
                                    deskripsi : "<?= $value['deskripsiTugas']?>",
                                    start     : "<?= $value['tanggaldiberiTugas']?>",
                                    end       : "",
                                    backgroundColor : "green"
                                },
                            <?php } ?>
                        ]
                    });
                    calendarTugas.render();
                }
            });
        });
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelWorkspace\your_tasks\resources\views/tugas/mode-kalendar/index.blade.php ENDPATH**/ ?>