<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright my-auto">
            <span class="float-start">Copyright &copy; your_tasks 2021</span>
            <span class="float-end">Crafted By ANDREE MEILIO CANIAGO</span>
        </div>
    </div>
</footer>
<!-- End of Footer --><?php /**PATH D:\LaravelWorkspace\your_tasks\resources\views/layouts/footer.blade.php ENDPATH**/ ?>