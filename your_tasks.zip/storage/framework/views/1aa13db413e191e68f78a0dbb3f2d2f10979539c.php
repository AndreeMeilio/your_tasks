

<?php $__env->startSection('content'); ?>

<a class="btn btn-success" href="<?php echo e(route('matapelajaranCreate')); ?>"><i class="fas fa-book-medical"></i></a>

<div class="table-responsive">
    <table class="table" id="tableMatapelajaran">
        <thead>
            <div class="row">
                <tr>
                    <th class="col-9 col-md-9">Nama Mata Pelajaran</th>
                    <th class="col-3 col-md-3">Aksi</th>
                </tr>
            </div>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data_mata_pelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <tr>
                        <td class="col-9 col-md-9"><?php echo e($mp->namaMatapelajaran); ?></td>
                        <td class="col-3 col-md-3">
                            <abbr title="Klik untuk mengedit data mata pelajaran ini"><a class="btn btn-secondary w-10 h-10 rounded-circle" href="<?php echo e(route('matapelajaranEdit', ['idMatapelajaran' => $mp->id])); ?>"><i class="fas fa-pen-square"></i></a></abbr>
                            <abbr title="Klik untuk melihat detail data mata pelajaran ini"><a class="btn btn-info w-10 h-10 rounded-circle" href="<?php echo e(route('matapelajaranDetail', ['idMatapelajaran' => $mp->id])); ?>"><i class="fas fa-info-circle"></i></a></abbr>
                            <abbr title="Klik untuk menghapus data mata pelajaran ini"><button class="btn btn-danger w-10 h-10 rounded-circle buttonHapus" value="<?php echo e($mp->id); ?>"><i class="fas fa-trash-alt"></i></button></abbr>
                            <abbr title="Klik untuk melihat tugas pada mata pelajaran ini"><a class="btn btn-primary w-10 h-10 rounded-circle" href="<?php echo e(route('tugas', ['idMatapelajaran' => $mp->id])); ?>"><i class="fas fa-book-open"></i></a></abbr>

                        </td>
                    </tr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    
    <div class="d-none d-lg-none">
        <form id="formHapus" method="POST"><?php echo csrf_field(); ?><input name="idMatapelajaran" id="idMatapelajarantext" type="text"><input type="submit" id="submitButton"></form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

    
    <script>
        const tableElement = document.querySelector("#tableMatapelajaran");
        const dataTable = new simpleDatatables.DataTable(tableElement);
    </script>

    <script>
        $(document).ready(function(){

            $(document).on('click', '.buttonHapus', function(){
                var idMatapelajaran = $(this).val();

                $.confirm({
                    title: 'Hapus Data Mata Pelajaran',
                    content: 'Seluruh Tugas Pada Mata Pelajaran Ini Akan Ikut Terhapus. Apa Anda Yakin Ingin Menghapus Data Ini',
                    type: 'red',
                    typeAnimated: true,
                    autoClose : 'cancelAction|10000',
                    buttons: {
                        tryAgain: {
                            text: 'Yakin',
                            btnClass: 'btn-red',
                            action: function(){
                                $("#formHapus").attr('action', '/matapelajaran/delete');
                                $('#idMatapelajarantext').val(idMatapelajaran);

                                $('#submitButton').click();
                            }
                        },
                        cancelAction: function () {
                        }
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelWorkspace\your_tasks\resources\views/matapelajaran/index.blade.php ENDPATH**/ ?>