

<?php $__env->startSection('content'); ?>
<div class="table-responsive">
    <table class="table" id="tableMatapelajaran">
        <thead>
            <div class="row">
                <tr>
                    <th class="col-3 col-md-3">Nama Mata Pelajaran</th>
                    <th class="col-2 col-md-2">Nama Tugas</th>
                    <th class="col-3 col-md-3">Tanggal Akhir Tugas</th>
                    <th class="col-2 col-md-2">Status</th>
                    <th class="col-2 col-md-2">Aksi</th>
                </tr>
            </div>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data_tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <tr style="font-weight: bold; color: black;" bgcolor="<?php echo e($item->statustugas->colorStatustugas); ?>">
                        <td class="col-3 col-md-3"><?php echo e($item->matapelajaran->namaMatapelajaran); ?></td>
                        <td class="col-2 col-md-2"><?php echo e($item->namaTugas); ?></td>
                        <td class="col-3 col-md-3"><?php echo e($item->tanggaldeadlineTugas); ?></td>
                        <td class="col-2 col-md-2"><?php echo e($item->statustugas->deskripsiStatustugas); ?></td>
                        <td class="col-3 col-md-3">
                            <abbr title="Klik untuk mencabut tugas sebagai tugas berbintang"><button class="btn btn-warning w-10 h-10 ms-1 rounded-circle buttonTugasBerbintang" value="<?php echo e($item->id); ?>"><i class="fas fa-star"></i></button></abbr>
                            <abbr title="Klik untuk melihat tugas pada mata pelajaran ini"><a class="btn btn-primary w-10 h-10 rounded-circle" href="<?php echo e(route('tugas', ['idMatapelajaran' => $item->matapelajaran->id])); ?>"><i class="fas fa-book-open"></i></a></abbr>

                        </td>
                    </tr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelWorkspace\your_tasks\resources\views/tugas/tugas_berbintang.blade.php ENDPATH**/ ?>