


<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('tugasUpdate', ['idMatapelajaran' => $idMatapelajaran, 'idTugas' => $tugas->id])); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="namaTugas" class="form-label">Nama Tugas</label>
        <input type="text" name="namaTugas" class="form-control" id="namaTugas" value="<?php echo e($tugas->namaTugas); ?>">
    </div>
    <div class="mb-3">
        <label for="tanggaldiberiTugas" class="form-label">Tanggal Diberi Tugas</label>
        <input type="text" name="tanggaldiberiTugas" class="form-control" id="tanggaldiberiTugas" value="<?php echo e($tugas->tanggaldiberiTugas); ?>" data-field="date" readonly>
    </div>
    <div class="mb-3">
        <label for="tanggaldeadlineTugas" class="form-label">tanggaldeadlineTugas</label>
        <input type="text" name="tanggaldeadlineTugas" class="form-control" id="tanggaldeadlineTugas" value="<?php echo e($tugas->tanggaldeadlineTugas); ?>" data-field="date" readonly>
    </div>
    
    <div id="dateBox"></div>

    <div class="mb-3">
        <label for="tempatpengumpulanTugas" class="form-label">Tempat Pengumpulan Tugas (Optional)</label>
        <input type="text" name="tempatpengumpulanTugas" class="form-control" id="tempatpengumpulanTugas" value="<?php echo e($tugas->tempatpengumpulanTugas); ?>">
    </div>
    <div class="mb-3">
        <label for="guruBersangkutan" class="form-label">Guru Yang Bersangkutan (Optional)</label>
        <input type="text" name="guruBersangkutan" class="form-control" id="guruBersangkutan" value="<?php echo e($tugas->guruBersangkutan); ?>">
    </div>
    <div class="mb-3">
        <label for="deskripsiTugas" class="form-label">Deskripsi Tugas (Optional)</label>
        <div class="form-floating">
            <textarea name="deskripsiTugas" class="form-control" placeholder="Deskripsi Mata Pelajaran" id="floatingTextarea2"
                style="height: 100px"><?php echo e($tugas->deskripsiTugas); ?></textarea>
            <label for="floatingTextarea2">Deskripsi Tugas</label>
        </div>
    </div>

    <a class="btn btn-secondary" href="<?php echo e(route('tugas', ['idMatapelajaran' => $idMatapelajaran])); ?>">Back</a>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function(){
            $("#dateBox").DateTimePicker();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelWorkspace\your_tasks\resources\views/tugas/edit.blade.php ENDPATH**/ ?>