<!-- Vendor -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/bootstrap.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fontawesome/all.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/simple-datatables/style.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-confirm/jquery-confirm.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/date-time-picker/DateTimePicker.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fullcalendar/main.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/apex-chart/apexcharts.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fil-pond/filepond.min.css')); ?>" type="text/css">



<link rel="stylesheet" href="<?php echo e(asset('assets/css/sb-admin-2.min.css')); ?>"><?php /**PATH D:\LaravelWorkspace\your_tasks\resources\views/layouts/vendor/vendor_css.blade.php ENDPATH**/ ?>