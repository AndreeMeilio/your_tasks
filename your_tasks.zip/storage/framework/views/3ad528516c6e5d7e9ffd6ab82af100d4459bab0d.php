

<?php $__env->startSection('content'); ?>
<div class="d-none d-lg-none" id="idMatapelajaran"><?php echo e($idMatapelajaran); ?></div>

<div id="notifikasi"></div>

<a class="btn btn-success" href="<?php echo e(route('tugasCreate', ['idMatapelajaran' => $idMatapelajaran])); ?>"><i class="fas fa-book-medical"></i></a>

<select id="statusTugas" class="form-select mb-3" aria-label="Default select example">
    <option value="" selected>Lihat Tugas Berdasarkan</option>
    <?php $__currentLoopData = $data_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->id); ?>"><?php echo e($item->deskripsiStatustugas); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<div class="row">
    <div class="col-6 col-lg-6">
        Jumlah Tugas : <span id="jumlahTugas"></span>
    </div>
    <div class="col-6 col-lg-6">
        <a class="btn btn-secondary float-end" href="<?php echo e(route('tugasKalendarMode', ['idMatapelajaran' => $idMatapelajaran])); ?>"><i class="fas fa-fw fa-calendar-alt"></i><span>Kalendar Mode</span></a>
    </div>
</div>

<div class="table-responsive">
    <div class="d-none d-lg-inline">
        <table class="table" id="tableTugas">
            <thead>
                <div class="row">
                    <tr style="font-weight: bold; color: black">
                        <th class="col-md-2">Nama Tugas</th>
                        <th class="col-md-2">Tanggal Akhir Tugas</th>
                        <th class="col-md-2">Tempat Pengumpulan Tugas</th>
                        <th class="col-md-1">Waktu Tersisa</th>
                        <th class="col-md-2">Status</th>
                        <th class="col-md-3">Aksi</th>
                    </tr>
                </div>
            </thead>
            <tbody id="data_tugas_tabel">
                
            </tbody>
        </table>
    </div>

    
    <div class="d-inline d-lg-none">
        <table class="table" id="tableTugasMobile">
            <thead>
                <div class="row">
                    <tr>
                        <th class="col-4">Nama Tugas</th>
                        <th class="col-4">Tanggal Akhir Tugas</th>
                        <th class="col-4">Aksi</th>
                    </tr>
                </div>
            </thead>
            <tbody id="data_tugas_tabel_mobile">
                
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('assets/js/tugas/tugas.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelWorkspace\your_tasks\resources\views/tugas/index.blade.php ENDPATH**/ ?>