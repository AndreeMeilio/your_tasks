


<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('matapelajaranStore')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="namaMataPelajaran" class="form-label">Nama Mata Pelajaran</label>
        <input type="text" name="namaMataPelajaran" class="form-control" id="namaMataPelajaran" aria-describedby="IPA, IPS, .....">
    </div>
    <div class="mb-3">
        <label for="deskripsiMataPelajaran" class="form-label">Deskripsi</label>
        <div class="form-floating">
            <textarea name="deskripsiMataPelajaran" class="form-control" placeholder="Deskripsi Mata Pelajaran" id="floatingTextarea2"
                style="height: 100px"></textarea>
            <label for="floatingTextarea2">Deskripsi Mata Pelajaran</label>
        </div>
    </div>

    <a class="btn btn-secondary" href="<?php echo e(route('matapelajaran')); ?>">Back</a>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelWorkspace\your_tasks\resources\views/matapelajaran/create.blade.php ENDPATH**/ ?>